import React from "react";
import "./index.css"
function Card(prop){
    return(
    
    <div className ="cards">
      <div className ="card">
        <img src={prop.imgsrc} alt ="my pic" className =" card__img"/>
        <div className ="card__info">
        <spam className ="card__category">{prop.title}</spam>
        <h1 className="card__title">{prop.sname}</h1>
        <a href={prop.link} target="blank">
          <button>watch now</button>
        </a>
        </div>
      </div>
    </div>
    
  );
  }
export default Card;