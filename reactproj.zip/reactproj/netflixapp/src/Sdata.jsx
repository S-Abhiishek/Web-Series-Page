
const Sdata =[
    {
      imgsrc :"https://cdn.dnaindia.com/sites/default/files/styles/full/public/2020/04/23/903342-netflix-dark.jpg",
    title :"netflix original series",
    sname :"dark",
    link:"https://www.netflix.com/in/title/80100172",
    },
    {
        imgsrc :"https://images.unsplash.com/photo-1546587348-d12660c30c50?ixid=MnwxMjA3fDB8MHxzZWFyY2h8NXx8bmF0dXJhbHxlbnwwfHwwfHw%3D&ixlib=rb-1.2.1&w=1000&q=80",
        sname :"lost in space",
        title :"netflix original series",
        link:"https://www.netflix.com/in/title/80104198",
    },
    {
        imgsrc :"https://english.cdn.zeenews.com/sites/default/files/styles/zm_700x400/public/2021/05/25/938590-money-heist.png",
        sname :"money heist",
        link:"https://www.netflix.com/in/title/80192098",
    },
    {
        imgsrc :"https://m.media-amazon.com/images/M/MV5BN2ZmYjg1YmItNWQ4OC00YWM0LWE0ZDktYThjOTZiZjhhN2Q2XkEyXkFqcGdeQXVyNjgxNTQ3Mjk@._V1_.jpg",
        title :"netflix original series",
        sname :"stranger things",
        link :"https://www.netflix.com/in/title/80057281",
    },
    {
        imgsrc :"https://images.unsplash.com/photo-1611920507986-b41638a9054f?ixid=MnwxMjA3fDB8MHxzZWFyY2h8MXx8bWF6ZSUyMHJ1bm5lcnxlbnwwfHwwfHw%3D&ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=60",
        title :"netflix original series",
        sname :"Maze Runner",
        link :"https://www.netflix.com/in/title/80057281",
    },
    {
        imgsrc :"https://images.unsplash.com/photo-1572527561845-bf58d45376bc?ixid=MnwxMjA3fDB8MHxzZWFyY2h8Mnx8em9tYmllfGVufDB8fDB8fA%3D%3D&ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=60",
        title :"netflix original series",
        sname :"World war z",
        link :"https://www.netflix.com/in/title/80057281",
    },
    {
        imgsrc :"https://images.unsplash.com/photo-1620712943543-bcc4688e7485?ixid=MnwxMjA3fDB8MHxzZWFyY2h8NXx8bXIlMjByb2JvdHxlbnwwfHwwfHw%3D&ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=60",
        title :"netflix original series",
        sname :"Mr Robot",
        link :"https://www.netflix.com/in/title/80057281",
    },
    {
        imgsrc :"https://images.unsplash.com/photo-1616061098842-e5b18be81f5a?ixid=MnwxMjA3fDB8MHxzZWFyY2h8Mnx8c3RldmUlMjBqb2JzfGVufDB8fDB8fA%3D%3D&ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=60",
        title :"netflix original series",
        sname :"Steve Jobs",
        link :"https://www.netflix.com/in/title/80057281",
    }

];
export default Sdata;